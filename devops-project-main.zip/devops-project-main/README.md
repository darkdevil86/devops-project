# devops-project
<a href="https://discord.gg/M7Sucgcsf5"><img src="https://img.shields.io/discord/1227264173948538941?color=5865F2&logo=discord&logoColor=white" alt="Discord server" /></a>